﻿namespace Dynamic.Framework.Generic
{
    class ApplicationManager
    {
    }
}
