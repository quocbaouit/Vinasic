﻿namespace Dynamic.Framework
{
    public enum eLanguage
    {
        Vi,
        En,
    }
}
