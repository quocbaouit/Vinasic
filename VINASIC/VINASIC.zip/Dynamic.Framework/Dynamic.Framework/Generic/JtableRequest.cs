﻿namespace Dynamic.Framework.Generic
{
    public class JtableRequest
    {
        public string keyword { get; set; }

        public int jtStartIndex { get; set; }

        public int jtPageSize { get; set; }

        public string jtSorting { get; set; }
    }
}
