﻿using System;

namespace Dynamic.Framework.Generic
{
    [Serializable]
    public class FileItem
    {
        public string FileName { get; set; }

        public string Path { get; set; }
    }
}
