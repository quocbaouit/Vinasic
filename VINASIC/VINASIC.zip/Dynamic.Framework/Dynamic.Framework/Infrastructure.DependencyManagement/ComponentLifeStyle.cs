﻿namespace Dynamic.Framework.Infrastructure.DependencyManagement
{
    public enum ComponentLifeStyle
    {
        Singleton,
        Transient,
        LifetimeScope,
    }
}
