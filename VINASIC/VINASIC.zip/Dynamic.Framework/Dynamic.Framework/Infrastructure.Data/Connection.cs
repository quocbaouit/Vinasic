﻿namespace Dynamic.Framework.Infrastructure.Data
{
    public class Connection
    {
        public string Name { get; set; }
    }
}
