﻿namespace Dynamic.Framework.Mvc
{
    public class Error
    {
        public string MemberName { get; set; }

        public string Message { get; set; }
    }
}
