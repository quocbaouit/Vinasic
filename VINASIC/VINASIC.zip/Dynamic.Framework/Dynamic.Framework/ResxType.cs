﻿namespace Dynamic.Framework
{
    public class ResxType
    {
        public string Name { get; set; }

        public string UICulture { get; set; }

        public bool IsDefault { get; set; }
    }
}
