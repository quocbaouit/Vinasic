﻿namespace Dynamic.Framework
{
    public enum SortDirection
    {
        Ascending,
        Descending,
    }
}
